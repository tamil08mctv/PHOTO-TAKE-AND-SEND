file_data = f.read()
