import cv2

face_cascade = cv2.CascadeClassifier('C:\\Users\\Tamiltech08\\AppData\\Local\\Programs\\Python\\Python310\\Lib\\site-packages\\cv2\\data\\haarcascade_frontalface_default.xml')

# Set up the video capture device
cap = cv2.VideoCapture(0)
# Set up the face detection model
face_cascade = cv2.CascadeClassifier('C:\\Users\\Tamiltech08\\AppData\\Local\\Programs\\Python\\Python310\\Lib\\site-packages\\cv2\\data\\haarcascade_frontalface_default.xml')

# Set up the video capture device
cap = cv2.VideoCapture(0)

while True:
    # Capture frame-by-frame
    ret, frame = cap.read()

    # Convert the frame to grayscale for face detection
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    # Detect faces in the frame
    faces = face_cascade.detectMultiScale(gray,1.1,4)

    # Draw rectangles around the faces and display the frame
    for (x, y, w, h) in faces:
        cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)

    cv2.imshow('frame', frame)
    if cv2.waitKey(3) & 0xFF == ord('q'):
        break

# Release the capture device and close the window
cap.release()
cv2.destroyAllWindows()

