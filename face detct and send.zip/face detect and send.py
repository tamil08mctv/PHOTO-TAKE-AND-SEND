import cv2
import smtplib
import imghdr
from email.message import EmailMessage

# Set up the email message
msg = EmailMessage()
msg['Subject'] = 'Face detected'
msg['From'] = 'tamilmctv02@gmail.com'
msg['To'] = 'pradeepkumarkaliannan12@gmail.com'
msg.set_content('Face detected in image.')

# Set up the email server
smtp_server = 'smtp.gmail.com'
smtp_port = 587
smtp_username = 'tamilmctv02@gmail.com'
smtp_password = 'uzulqrbdrdmnzimt'

# Set up the face detection model
face_cascade = cv2.CascadeClassifier('C:\\Users\\Tamiltech08\\AppData\\Local\\Programs\\Python\\Python310\\Lib\\site-packages\\cv2\\data\\haarcascade_frontalface_default.xml')

# Set up the video capture device
cap = cv2.VideoCapture(0)

while True:
    # Capture frame-by-frame
    ret, frame = cap.read()

    # Convert the frame to grayscale for face detection
    gray = cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY)

    # Detect faces in the frame
    faces = face_cascade.detectMultiScale(gray,1.1,4)

    # Draw rectangles around the faces and display the frame
    for (x, y, w, h) in faces:
        cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)

    cv2.imshow('frame', frame)

    # Send an email if faces are detected
    if len(faces) > 0:
        cv2.imwrite('face_detected.jpg', frame)
        with open('face_detected.jpg', 'rb') as f:
            file_data = f.read()
            file_type = imghdr.what(f.name)
            file_name = f.name
        msg.add_attachment(file_data, maintype='image', subtype=file_type, filename=file_name)

        with smtplib.SMTP(smtp_server, smtp_port) as server:
            server.starttls()
            server.login(smtp_username, smtp_password)
            server.send_message(msg)

        break

    # Quit the program if the 'q' key is pressed
    if cv2.waitKey(3) & 0xFF == ord('q'):
        break

# Release the capture device and close the window
cap.release()
cv2.destroyAllWindows()
